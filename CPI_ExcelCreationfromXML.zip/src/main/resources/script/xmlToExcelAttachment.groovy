/*
 * This Groovy script generates an Excel workbook attachment based on the message body XML. 
 * The script uses Apache POI library for Excel generation. 
 * Apache POI reference - https://poi.apache.org/components/spreadsheet/
 * 
 * Sample source XML:
 * <root>
 *   <record>
 *     <id>1</id>
 *     <name>John</name>
 *   </record>
 *   <record>
 *     <id>2</id>
 *     <name>Jane</name>
 *   </record>
 * </root>
 */

import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.camel.impl.DefaultAttachment
import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.*
import javax.activation.DataHandler
import javax.mail.util.ByteArrayDataSource

def Message processData(Message message) {
    // Extract the source XML from the message body
    def sourceXml = message.getBody(String.class)
    
    // Parse the source XML to extract records
    def records = new XmlSlurper().parseText(sourceXml).record
    
    // Create a new workbook
    Workbook workbook = new XSSFWorkbook()
    
    // Create a sheet in the workbook with appropriate name
    Sheet sheet = workbook.createSheet("Primary Sheet")
    
    // Create a header row with column names
    Row headerRow = sheet.createRow(0)
    headerRow.createCell(0).setCellValue("ID")
    headerRow.createCell(1).setCellValue("Name")

    // Populate data in rows
    for(int i = 0; i < records.size(); i++) {
        def record = records[i]
        Row row = sheet.createRow(i+1)
        row.createCell(0).setCellValue(record.id.text())
        row.createCell(1).setCellValue(record.name.text())
    }
    
    // Convert workbook to byte array
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()
    workbook.write(byteArrayOutputStream)
    byte[] bytes = byteArrayOutputStream.toByteArray()
    
    // Construct a ByteArrayDataSource object with the byte array and the content's MIME type
    ByteArrayDataSource dataSource = new ByteArrayDataSource(bytes, "application/vnd.ms-excel")
    
    // Construct a DefaultAttachment object
    DataHandler dataHandler = new DataHandler(dataSource)
    DefaultAttachment attachment = new DefaultAttachment(dataHandler)
    
    // Add the attachment to the message
    message.addAttachmentObject("records.xlsx", attachment)
    
    return message
}
